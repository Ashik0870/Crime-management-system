<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>

    <form action="upload.php" method="post">
      <input type="file" name="file" >
      <input type="submit" name="submit" value="UPLOAD">

    </form>
  </body>
</html>
