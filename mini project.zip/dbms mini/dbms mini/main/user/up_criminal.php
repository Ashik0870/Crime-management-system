<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
<?php
$con = mysqli_connect('localhost','root',"");
mysqli_select_db($con, 'crime');
               if(isset($_POST['submit']))
               {
                 // $id = $row['tid'];
                 $id=$_POST['id'];
                 $type=$_POST['type'];
                 $name=$_POST['name'];
                 $age=$_POST['age'];
                 $address=$_POST['address'];
                 $pno=$_POST['pno'];
                 $targetDir = "../uploads/";
                 $fileName = basename($_FILES["file"]["name"]);
                 $targetFilePath = $targetDir . $fileName;
                 $fileType = pathinfo($targetFilePath,PATHINFO_EXTENSION);
                 move_uploaded_file($_FILES["file"]["tmp_name"], $targetFilePath);
                 // $fileName=$_POST['fileName'];
                 $query3 = mysqli_query($con,"UPDATE criminal SET criminal_id='$id',crime_type='$type',criminal_name='$name',age='$age',criminal_add='$address',criminal_pno='$pno',file_name='$fileName' WHERE criminal_id='$id'");

                   if ($query3)
                       {
                        header('location:viewcriminal.php');
                       }
                       // echo "<script type='text/javascript'>alert('Successful - Record Updated!'); window.location.href = 'user_list.php';</script>"; }
                   else
                       { echo "<script type='text/javascript'>alert('Unsuccessful - ERROR!'); window.location.href = 'user_list.php';</script>"; }
               }

   // $query1=mysql_query("SELECT * FROM u_login WHERE u_id=$id");
   // $query2=mysql_fetch_array($query1);
?>
</body>
</html>
