<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Police Management System</title>
    <style>
    body{
   background: url(mainbg.jpg);
   background-repeat: no-repeat;
   background-size: cover;

    }
    .containar{
          width: 90%;
          margin: 0 auto; /* Center the DIV horizontally */
      }
      .fixed-header, .fixed-footer{
          width: 100%;
          position: fixed;
          background: #444;
          padding: 10px 0;
          color: #fff;
      }
      .fixed-header{
          top: 0;
      }
      .fixed-footer{
          bottom: 0;
      }
      /* Some more styles to beutify this example */
      nav a{
          color: #fff;
          text-decoration: none;
          padding: 7px 25px;
          display: inline-block;
      }
      .container p{
          line-height: 200px; /* Create scrollbar to test positioning */
      }

</style>
  </head>
  <body >
   <br><br><br><br><center><h1 style="color:White; font-size:60px;">Police Management System</h1></center>
   <div class="fixed-header">
       <div class="containar">
           <nav>
               <a href="#"><h1>Home</h1></a>
               <a href="#"><h1>About</h1></a>
               <a href="login.php"><h1>Login</h1></a>
           </nav>
       </div>
   </div>
   <div class="">
     <div class="internal">
       <h2>Features of Police Management System</h2>
       <div class="">
         <img src="" alt="">
       </div>
     </div>

   </div>
  </body>
</html>
